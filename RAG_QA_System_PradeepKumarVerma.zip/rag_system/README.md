# RAG-Based Question Answering System

**Author:** Pradeep Kumar Verma  
**Role:** Senior SDET & QA Automation Engineer  
**GitHub:** [github.com/erprad8](https://github.com/erprad8) | **LinkedIn:** [linkedin.com/in/erprad8](https://linkedin.com/in/erprad8)

---

## Overview

A production-ready **Retrieval-Augmented Generation (RAG)** API that lets users upload documents (PDF and TXT) and ask natural-language questions answered by an LLM grounded in the uploaded content.

```
User → Upload PDF/TXT → Background Ingestion → FAISS Vector Store
User → Ask Question  → Embed Query → Similarity Search → LLM → Answer
```

---

## Features

| Feature | Implementation |
|---|---|
| Document formats | PDF, TXT |
| Chunking strategy | Sliding-window, sentence-boundary-aware, 512-token target |
| Embeddings | `all-MiniLM-L6-v2` (384-dim, sentence-transformers) |
| Vector store | FAISS `IndexFlatIP` (cosine similarity via normalised dot product) |
| LLM | Anthropic Claude Haiku (swappable) |
| Background ingestion | `ThreadPoolExecutor` — upload returns 202 immediately |
| Request validation | Pydantic v2 models |
| Rate limiting | slowapi — 10 uploads/min, 30 queries/min per IP |
| Persistence | FAISS index + pickle metadata survive restarts |
| Metrics | End-to-end latency, retrieval latency, avg similarity score, failure rate |

---

## Project Structure

```
rag_system/
├── app/
│   ├── main.py                  # FastAPI app, middleware, lifespan
│   ├── routers/
│   │   ├── documents.py         # POST /upload, GET /status, GET /list, GET /metrics
│   │   ├── query.py             # POST /ask
│   │   └── health.py            # GET /health
│   ├── services/
│   │   ├── parser_service.py    # PDF + TXT → text blocks
│   │   ├── chunking_service.py  # Sliding-window chunker
│   │   ├── embedding_service.py # sentence-transformers wrapper
│   │   ├── vector_store_service.py  # FAISS index management
│   │   ├── llm_service.py       # Anthropic Claude answer generation
│   │   ├── ingestion_job.py     # Background job manager
│   │   └── metrics_service.py   # In-memory metrics tracker
│   ├── models/
│   │   └── schemas.py           # Pydantic request/response models
│   └── utils/
│       └── logger.py            # Structured logging setup
├── tests/
│   └── test_services.py         # pytest unit tests
├── vector_store/                # Auto-created; stores FAISS index + metadata
├── logs/                        # Auto-created; rag_system.log
├── docs/
│   └── system_explanation.md    # Chunk size rationale, failure case, metrics
├── requirements.txt
├── .env.example
└── README.md
```

---

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/erprad8/rag-qa-system.git
cd rag-qa-system

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

> **Note:** First run downloads the `all-MiniLM-L6-v2` model (~90MB). Subsequent runs use the cached model.

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and set your ANTHROPIC_API_KEY
```

> **No API key?** The system still works — it returns the raw retrieved chunks instead of an LLM-synthesised answer.

### 3. Start the Server

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Visit **http://localhost:8000/docs** for the interactive Swagger UI.

---

## API Reference

### Upload a Document

```bash
curl -X POST http://localhost:8000/api/v1/documents/upload \
  -F "file=@/path/to/document.pdf"
```

**Response (202 Accepted):**
```json
{
  "doc_id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
  "filename": "document.pdf",
  "status": "pending",
  "message": "Document accepted. Poll /status/3fa8... to check progress."
}
```

### Check Ingestion Status

```bash
curl http://localhost:8000/api/v1/documents/status/3fa85f64-5717-4562-b3fc-2c963f66afa6
```

**Response:**
```json
{
  "doc_id": "3fa85f64-...",
  "filename": "document.pdf",
  "status": "completed",
  "total_chunks": 42
}
```

Status values: `pending` → `processing` → `completed` | `failed`

### Ask a Question

```bash
curl -X POST http://localhost:8000/api/v1/query/ask \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What is the refund policy for premium subscriptions?",
    "top_k": 5,
    "similarity_threshold": 0.3
  }'
```

**Response:**
```json
{
  "question": "What is the refund policy for premium subscriptions?",
  "answer": "According to the uploaded documents, premium subscriptions are eligible for a full refund within 30 days of purchase...",
  "retrieved_chunks": [
    {
      "chunk_id": "abc123",
      "text": "Premium subscribers may request a full refund...",
      "similarity_score": 0.8412,
      "filename": "policy.pdf",
      "chunk_index": 7,
      "page_number": 3
    }
  ],
  "latency_ms": 432.1,
  "retrieval_latency_ms": 12.3,
  "generation_latency_ms": 418.5,
  "avg_similarity_score": 0.7821,
  "model_used": "claude-3-haiku-20240307"
}
```

### Optional Query Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `top_k` | int | 5 | Number of chunks to retrieve (1–20) |
| `similarity_threshold` | float | 0.3 | Minimum cosine similarity (0.0–1.0) |
| `doc_ids` | list[str] | null | Restrict to specific document IDs |

### Other Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | System health + indexed chunk count |
| `/api/v1/documents/list` | GET | All documents + ingestion status |
| `/api/v1/documents/metrics` | GET | Query latency, similarity scores, failure rate |

---

## Running Tests

```bash
pytest tests/ -v
```

---

## Architecture

See `docs/system_explanation.md` for:
- Why chunk size = 512 tokens
- Retrieval failure case observed
- Metrics tracked

### High-Level Flow

```
┌──────────────┐     POST /upload      ┌───────────────────┐
│    Client    │ ───────────────────► │  FastAPI Router    │
└──────────────┘                       └────────┬──────────┘
                                                │ 202 Accepted
                                       ┌────────▼──────────┐
                                       │  Background Job    │
                                       │  (ThreadPoolExec)  │
                                       └────────┬──────────┘
                                                │
                              ┌─────────────────▼──────────────────┐
                              │           Ingestion Pipeline         │
                              │  PDF/TXT Parser → Chunker →          │
                              │  EmbeddingService → VectorStore      │
                              └─────────────────┬──────────────────┘
                                                │
                                       ┌────────▼──────────┐
                                       │   FAISS Index      │
                                       │  (IndexFlatIP)     │
                                       │  + Metadata Store  │
                                       └────────┬──────────┘
                                                │
┌──────────────┐    POST /ask          ┌────────▼──────────┐
│    Client    │ ───────────────────► │  Query Pipeline    │
└──────────────┘                       │  Embed → Search →  │
                                       │  LLM Generation    │
                                       └────────┬──────────┘
                                                │
                                       ┌────────▼──────────┐
                                       │  Anthropic Claude  │
                                       │  (Haiku / Sonnet)  │
                                       └───────────────────┘
```

---

## Configuration

| Variable | Default | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | — | Required for LLM generation |
| `CHUNK_SIZE_CHARS` | 1500 | ~512 tokens at 3 chars/token |
| `OVERLAP_CHARS` | 200 | ~50-token overlap between chunks |
| `UPLOAD_RATE_LIMIT` | 10/minute | Per-IP upload rate |
| `QUERY_RATE_LIMIT` | 30/minute | Per-IP query rate |

---

## Design Decisions

### Why not LangChain/LlamaIndex?
These frameworks abstract away the chunking, retrieval, and prompt logic — making it hard to explain *why* the system behaves a certain way. This project implements each layer explicitly so every design choice is visible and justifiable (required by the evaluation criteria).

### Why FAISS (local) over Pinecone?
- No API key, no network call, zero cost for development.
- `IndexFlatIP` gives **exact** nearest-neighbour search — no approximation error.
- Suitable for corpora up to ~500K chunks. Scale up to `IndexIVFFlat` or Pinecone for production.

### Why `all-MiniLM-L6-v2`?
- Apache 2.0 licensed, 22M parameters, runs on CPU in <15ms per chunk.
- 512-token context window aligns perfectly with our chosen chunk size.
- Outperforms larger models on many semantic similarity benchmarks at a fraction of the inference cost.

---

## License

MIT — Free for commercial and personal use.
