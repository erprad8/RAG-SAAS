"""
Unit tests for RAG system services.
Author: Pradeep Kumar Verma

Run with: pytest tests/ -v
"""

import pytest
from app.services.chunking_service import ChunkingService, CHUNK_SIZE_CHARS, OVERLAP_CHARS
from app.services.parser_service import DocumentParser, UnsupportedFormatError


# ─── Chunking Tests ────────────────────────────────────────────────────────────

class TestChunkingService:

    def test_short_text_produces_single_chunk(self):
        svc = ChunkingService()
        text = "This is a short document."
        blocks = [(text, {"filename": "test.txt", "page_number": None})]
        chunks = svc.chunk_document(blocks, "doc-001")
        assert len(chunks) == 1
        assert chunks[0].text == text

    def test_long_text_produces_multiple_chunks(self):
        svc = ChunkingService(chunk_size=200, overlap=50)
        text = ("word " * 200).strip()   # ~1000 chars
        blocks = [(text, {"filename": "test.txt", "page_number": None})]
        chunks = svc.chunk_document(blocks, "doc-002")
        assert len(chunks) > 1

    def test_chunks_have_correct_metadata(self):
        svc = ChunkingService()
        text = "Hello world. " * 20
        blocks = [(text, {"filename": "sample.pdf", "page_number": 3})]
        chunks = svc.chunk_document(blocks, "doc-003")
        for chunk in chunks:
            assert chunk.metadata.doc_id == "doc-003"
            assert chunk.metadata.filename == "sample.pdf"
            assert chunk.metadata.total_chunks == len(chunks)

    def test_chunk_overlap_preserves_boundary_content(self):
        """Boundary content (split across chunks) should appear in at least one chunk."""
        svc = ChunkingService(chunk_size=100, overlap=30)
        # Place a unique phrase near the boundary
        text = "A" * 80 + "BOUNDARY_PHRASE" + "B" * 80
        blocks = [(text, {"filename": "test.txt", "page_number": None})]
        chunks = svc.chunk_document(blocks, "doc-004")
        found = any("BOUNDARY_PHRASE" in c.text for c in chunks)
        assert found, "Boundary content should appear in at least one chunk due to overlap."

    def test_empty_text_returns_no_chunks(self):
        svc = ChunkingService()
        blocks = [("   ", {"filename": "empty.txt", "page_number": None})]
        chunks = svc.chunk_document(blocks, "doc-005")
        assert len(chunks) == 0

    def test_sentence_boundary_detection(self):
        svc = ChunkingService(chunk_size=50, overlap=10)
        result = svc._find_sentence_boundary("Hello world. This is text.", 15)
        # Should find the period at position 12
        assert result == 13  # after the period

    def test_chunk_ids_are_unique(self):
        svc = ChunkingService(chunk_size=200, overlap=50)
        text = ("Lorem ipsum dolor sit amet. " * 50)
        blocks = [(text, {"filename": "test.txt", "page_number": None})]
        chunks = svc.chunk_document(blocks, "doc-006")
        ids = [c.chunk_id for c in chunks]
        assert len(ids) == len(set(ids)), "All chunk IDs must be unique."


# ─── Parser Tests ──────────────────────────────────────────────────────────────

class TestDocumentParser:

    def test_txt_parse_basic(self):
        parser = DocumentParser()
        text = "First paragraph.\n\nSecond paragraph."
        blocks = parser.parse(text.encode("utf-8"), "test.txt")
        assert len(blocks) == 2
        assert blocks[0][0] == "First paragraph."
        assert blocks[1][0] == "Second paragraph."

    def test_txt_parse_single_paragraph(self):
        parser = DocumentParser()
        text = "Only one paragraph here."
        blocks = parser.parse(text.encode("utf-8"), "readme.txt")
        assert len(blocks) == 1

    def test_txt_metadata_contains_filename(self):
        parser = DocumentParser()
        blocks = parser.parse(b"Some content.", "myfile.txt")
        assert blocks[0][1]["filename"] == "myfile.txt"
        assert blocks[0][1]["page_number"] is None

    def test_unsupported_format_raises(self):
        parser = DocumentParser()
        with pytest.raises(UnsupportedFormatError):
            parser.parse(b"data", "document.docx")

    def test_unsupported_csv_raises(self):
        parser = DocumentParser()
        with pytest.raises(UnsupportedFormatError):
            parser.parse(b"col1,col2\n1,2", "data.csv")

    def test_txt_utf8_encoding(self):
        parser = DocumentParser()
        text = "Héllo wörld."
        blocks = parser.parse(text.encode("utf-8"), "unicode.txt")
        assert "Héllo" in blocks[0][0]


# ─── Schema Validation Tests ──────────────────────────────────────────────────

class TestQueryRequestValidation:

    def test_blank_question_raises(self):
        from pydantic import ValidationError
        from app.models.schemas import QueryRequest
        with pytest.raises(ValidationError):
            QueryRequest(question="   ")

    def test_question_too_short_raises(self):
        from pydantic import ValidationError
        from app.models.schemas import QueryRequest
        with pytest.raises(ValidationError):
            QueryRequest(question="hi")

    def test_valid_query_request(self):
        from app.models.schemas import QueryRequest
        q = QueryRequest(question="What is the refund policy?", top_k=3)
        assert q.top_k == 3
        assert q.similarity_threshold == 0.3

    def test_top_k_clamped(self):
        from pydantic import ValidationError
        from app.models.schemas import QueryRequest
        with pytest.raises(ValidationError):
            QueryRequest(question="Valid question here?", top_k=100)
